import 'package:flutter/material.dart';

class NotificationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notifications'),
      ),
      body: ListView(
        children: [
          ListTile(
            title: Text('Seminar on AI'),
            subtitle: Text('Date: 2024-12-31'),
          ),
          ListTile(
            title: Text('Exam Schedule Released'),
            subtitle: Text('Date: 2025-01-15'),
          ),
          ListTile(
            title: Text('Cultural Fest'),
            subtitle: Text('Date: 2025-02-20'),
          ),
        ],
      ),
    );
  }
}
