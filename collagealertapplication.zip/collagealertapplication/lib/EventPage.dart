import 'package:flutter/material.dart';

class EventPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Event Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Event Name: College Seminar',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text('Date: 2024-12-31'),
            Text('Time: 10:00 AM'),
            Text('Location: Auditorium A'),
            SizedBox(height: 20),
            Text('Description: This is a seminar on artificial intelligence.'),
          ],
        ),
      ),
    );
  }
}
