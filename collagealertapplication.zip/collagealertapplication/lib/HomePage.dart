import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('College Events'),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications),
            onPressed: () {
              Navigator.pushNamed(context, '/notifications');
            },
          ),
        ],
      ),
      body: ListView(
        children: [
          EventCategoryTile(category: 'Seminars', context: context),
          EventCategoryTile(category: 'Exams', context: context),
          EventCategoryTile(category: 'Extracurricular Activities', context: context),
        ],
      ),
    );
  }
}

class EventCategoryTile extends StatelessWidget {
  final String category;
  final BuildContext context;

  EventCategoryTile({required this.category, required this.context});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(category),
      onTap: () {
        Navigator.pushNamed(context, '/event');
      },
    );
  }
}
