import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import ' LoginPage.dart';
import 'EventPage.dart';
import 'HomePage.dart';
import 'NotificationPage.dart';
import 'ProfilePage.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'College Alert Application',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => LoginPage(),
        '/home': (context) => HomePage(),
        '/event': (context) => EventPage(),
        '/profile': (context) => ProfilePage(),
        '/notifications': (context) => NotificationPage(),
      },
    );
  }
}
