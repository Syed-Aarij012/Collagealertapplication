package com.example.collagealertapplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
